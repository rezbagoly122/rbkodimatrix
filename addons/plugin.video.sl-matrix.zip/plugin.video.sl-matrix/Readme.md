# Direct One LiveTV HU

##### ENG:

The plugin generates a playlist and EPG for the Direct One LiveTV service, for use in the IPTV Simple Client.

It also displays the Direct One archive as a video add-on.

In case of malfunction of playlist and epg generation (eg due to missing write rights), it is possible to display Live stations in the video plugin.

Based on [Sorien's](https://github.com/Sorien/plugin.video.sl) Skylink plugin.



##### HUN:

A plugin lejátszási listát és EPG-t generál Direct One LiveTV-hez az IPTV Simple Client számára,

továbbá hozzáférést biztosít a videótárhoz is.

Amennyiben a lejátszási lista és EPG generálás nem működik (pl.: hiányzó írási jog), az élő TV elérhető a video plugin-ból is.

A plugin [Sorien's](https://github.com/Sorien/plugin.video.sl) Skylink pluginja alapján készült.

